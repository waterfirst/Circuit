from pathlib import Path
import subprocess,os,numpy as np
base=Path('hpd.cir').read_text();env=os.environ.copy();env['LD_LIBRARY_PATH']='/workspace/scratch/7bb09ebd1f07/tools/ng/usr/lib/x86_64-linux-gnu';ng='/workspace/scratch/7bb09ebd1f07/tools/ng/usr/bin/ngspice'
new={'VGW':'VGW GW 0 PULSE(-9 8 100u 1u 1u 100u 1200u)','VGR':'VGR GR 0 PULSE(-9 8 10u 1u 1u 60u 1200u)','VGI':'VGI GI 0 PULSE(8 -9 10u 1u 1u 60u 1200u)','VEM':'VEM EM 0 PULSE(8 -9 300u 1u 1u 598u 1200u)','VEMB':'VEMB EMB 0 PWL(' + ' '.join(f'{1200*k+tt}u {vv}' for k in range(5) for tt,vv in [(0,8),(10,8),(11,-9),(70,-9),(71,8),(310,8),(311,-9),(889,-9),(890,8)]) + ' 6000u 8)'}
lines=base.splitlines();lines=[new.get(s.split(' ')[0],s) if s else s for s in lines];s='\n'.join(lines)+'\n';s=s.replace('tran 2u 1200.000u 0 10u','tran 1u 6000u 0 1u').replace('wrdata out.txt','wrdata improved.txt');Path('improved.cir').write_text(s)
for v in [1,2,3,4,5]:
 q=s.replace('VDATA DATA 0 3.0',f'VDATA DATA 0 {v}').replace('wrdata improved.txt',f'wrdata data{v}.txt');Path(f'data{v}.cir').write_text(q); p=subprocess.run([ng,'-b',f'data{v}.cir'],env=env,capture_output=True,text=True);Path(f'data{v}.log').write_text(p.stdout+p.stderr)
 d=np.loadtxt(f'data{v}.txt',skiprows=1);t=d[:,0]*1e6
 print('data',v,'points',len(t));
 for tm in [4800,4850,4890,4950,5005,5090,5115,5200,5600,5690,5750,5999]:
  print(tm,[round(np.interp(tm,t,d[:,i]),5) for i in (6,7,8,9)],round(np.interp(tm,t,d[:,10])*1e9,3))
 a,b=5150,5680;z=np.r_[a,t[(t>a)&(t<b)],b];print('avg nA',np.trapezoid(np.interp(z,t,d[:,10]),z)/(b-a)*1e9)
